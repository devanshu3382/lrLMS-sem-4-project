/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.slibrary.library.DB;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Devanshu
 */
public class myConnection {
    public static Connection con;
    public static Statement s;
    public static void loadConnection() throws SQLException{
        String url = "jdbc:mysql://localhost:3306/LMS";
        String userName = "root";
        String pass = "devanshu";
        
//        Connection conn = null;
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            conn = DriverManager.getConnection(url, userName, pass);
//            if (conn != null) {
//                System.out.println("Connected to the database");
//            }
//        } catch (ClassNotFoundException ex) {
//            System.out.println("Could not find database driver class");
//            ex.printStackTrace();
//        } catch (SQLException ex) {
//            System.out.println("An error occurred. Maybe user/password is invalid");
//            ex.printStackTrace();
//        } finally {
//            if (conn != null) {
//                try {
//                    conn.close();
//                } catch (SQLException ex) {
//                    ex.printStackTrace();
//                }
//            }
//        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url,userName,pass);
            s = con.createStatement();
            if(con == null){
                JOptionPane.showMessageDialog(null, "DB not loaded.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e);
        }
    }
}
