;
<?php $__env->startSection('title'); ?>
<title>
    Librarian | Reports | Books Currently Issued
</title>

<?php $__env->startSection('css'); ?>
<style>
.container{
    position:relative;
    left:22%;
    margin-top:5rem;
    width:78%;
    background:white;
}
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <center>
        <table cellspacing="20px" style="font-size:1.4rem">
            <tr>
                <th><center>Issue<br>Id</center></th>
                <th><center>Issued<br>To</center></th>
                <th><center>Book<br>Name</center></th>
                <th><center>Author<br>Name</center></th>
                <th><center>Issue<br>Date</center></th>
                <th><center>Return<br>Date</center></th>
                <th><center>Fined</center></th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><center><?php echo e($x->issue_id); ?></center></td>
                <td><center><?php echo e($x->student_id); ?></center></td>
                <td><center><?php echo e($x->book_name); ?></center></td>
                <td><center><?php echo e($x->book_author); ?></center></td>
                <td><center><?php echo e($x->issue_date); ?></center></td>
                <td><center><?php echo e($x->return_date); ?></center></td>
                <td><center><?php echo e($x->fined); ?></center></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </center>
</div>
<?php echo $__env->make('librarianHome.librarianMenuConnector', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/librarianHome/currentIssue.blade.php ENDPATH**/ ?>