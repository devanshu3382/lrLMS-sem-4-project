session_destroy();
<script>
    window.location="<?php echo e(url('/logout')); ?>";
</script><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/studentHome/studentLogout.blade.php ENDPATH**/ ?>