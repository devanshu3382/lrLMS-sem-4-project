
<?php $__env->startSection('css'); ?>
img {
    border-radius: 8px;
    height:400px;
    width:400px;
}
.total-books-box{
    position:relative;
    left:1%;
    max-width:40%;
    border-style:solid;
    border-color:red;
}
.current-books-box{
    position:relative;
    right:0;
    max-width:40%;
    border-style:solid;
    border-color:red;
}
.box{
    display: inline-block;
    width: 27%;
    height: 40%;
    border-style:solid;
    background-color:turquoise;
    border-size:20px;
    padding:10px;
    <!-- margin: 10px; -->
    font-weight:600;
    border-radius:20px;
}
.box1 {
    display: inline-block;
    width: 27%;
    height: 40%;
    border-style:solid;
    background-color:#FEE715FF;
    border-size:20px;
    padding:10px;
    <!-- margin: 10px; -->
    font-weight:600;
    border-radius:20px;
}

.box2 {
    display: inline-block;
    width: 27%;
    height: 40%;
    border-style:solid;
    background-color:#3f681c;
    border-size:20px;
    padding:10px;
    <!-- margin: 10px; -->
    font-weight:600;
    border-radius:20px;
}

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Student Corner | Home</title>


<?php $__env->startSection('content'); ?>
<center>
    <!-- <div class="child">
        <center>
            <h1>Some Basic Text</h1>        
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima nostrum, ratione quidem similique quibusdam repudiandae laborum repellendus! Facere fugiat odio quasi nesciunt aut debitis voluptatem dignissimos. Aperiam necessitatibus aliquid tempore?
            </p>
        </center>
    </div> -->


    <?php if(session('totalBook')==0): ?>
        <div class="box">
            <center>
                <h2>
                    Total
                </h2>        
                    <p style="font-size:40px">
                        <?php echo e(session('totalBook')); ?>

                    </p>
                    
                        <!-- {$numIssuedTotal;} -->
                    
                <h3>
                    Books<br>Issued    
                </h3>
            </center>
        </div>
    <?php endif; ?>
    <?php if(session('totalBook')!=0): ?>
    <a href="<?php echo e(url('/student/totalBooksIssued')); ?>">
        <div class="box">
            <center>
                <h2>
                    Total
                </h2>        
                    <p style="font-size:40px">
                        <?php echo e(session('totalBook')); ?>

                    </p>
                    
                        <!-- {$numIssuedTotal;} -->
                    
                <h3>
                    Books<br>Issued    
                </h3>
            </center>
        </div>
    </a>
    <?php endif; ?>

    <a href="<?php echo e(url('/student/currentBooksIssued')); ?>">
        <div class="box1">
            <center>
                <h2>
                    Currently
                </h2>        
                    <p style="font-size:40px">
                        <?php echo e(session('issuedBooks')); ?>

                        
                            <!-- {$numCurrent;} -->
                        
                    </p>
                <h3>
                    Books<br>Issued
                </h3>
            </center>
        </div>
    </a>

    <?php if(session('reservedBooks')==0): ?>
    <!-- <a href="<?php echo e(url('/student/booksReserved')); ?>"> -->
        <div class="box2" style="margin:20px">
            <center> 
                <h2>
                    Currently
                </h2>        
                <p style="font-size:40px">
                        <?php echo e(session('reservedBooks')); ?>

                            
                    </p>
                <h3>
                    Books<br>Reserved
                </h3>
                <!-- <p style="color:#3f681c">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis unde quo, deleniti veniam assumenda cupiditate, error ut obcaecati placeat rerum provident amet?
                </p> -->
            </center>
        </div>
    <!-- </a> -->
    <?php endif; ?>
    <?php if(session('reservedBooks')!=0): ?>
    <a href="<?php echo e(url('/student/booksReserved')); ?>">
        <div class="box2">
            <center> 
                <h2>
                    Currently
                </h2>        
                <p style="font-size:40px">
                        <?php echo e(session('reservedBooks')); ?>

                            
                    </p>
                <h3>
                    Books<br>Reserved
                </h3>
                <!-- <p style="color:#3f681c">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis unde quo, deleniti veniam assumenda cupiditate, error ut obcaecati placeat rerum provident amet?
                </p> -->
            </center>
        </div>
    </a>
    <?php endif; ?>
    
    
</center>
<script>
    console.log(<?php echo e(session('uname')); ?>);
</script>

<?php if($message=Session::get('success')): ?>
    <script>
        alert('<?php echo e($message); ?>')
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('studentHome.studentLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/studentHome/studentHome.blade.php ENDPATH**/ ?>