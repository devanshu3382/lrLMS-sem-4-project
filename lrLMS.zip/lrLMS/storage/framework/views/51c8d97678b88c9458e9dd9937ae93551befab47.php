<?php $__env->startSection('title'); ?>
<title>Librarian | Issuing Book</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
.blurs{
    margin: 0;
    padding: 0;
    width: 100%;
    -webkit-backdrop-filter: blur(4px);
    backdrop-filter: blur(4px);
    font-size:1.75em;
    /* height:900px; */
    right:0;  
}
.transs{
    margin: 0;  
    background-color: #ffffff;
    /* border: 1px solid black; */
    /*border-radius:20px;*/
    opacity: 0.7;
}
.container{
    padding: 0;
    padding-left: 20px;
    top: 30%;
    height: 600px;
}
.rounded
{
    font-size:16pt;
    border-radius:20px;
    box-shadow: 2px 2px 3px #666;
    padding-left: 10px;
}
.submitRounded{
	margin:10px;
	margin-left:40px;
	background-color:#1cac78;
	border-radius:15px;
	font-size:16pt;
	width:150px;	
}
.rounded:focus{
    font-size:16pt;
    border-radius:0px;
    background-color:lightblue;
    box-shadow: 2px 2px 3px #666;
    border-color: #339933;
}
</style>
<?php $__env->startSection('content'); ?>
    <div class="blurs">
        <div class="transs">
            <div class="container">
                <center>
                    <h1 style="text-decoration:underline">
                        Issuing books to students
                    </h1>
                    
                    <form action="/issue/book-to-student" method="post">
                    <?php echo csrf_field(); ?>
                        <table style="font-size:1.5rem;padding-top:7%;" cellspacing="20px" cellpadding="10px">
                           <tr>
                                <td>
                                    <label>Book to be issued :</label>
                                </td>
                                <td>
                                    <input class="rounded" value="<?php echo e($bookId); ?>" type="text" value="<?php $bookName ?>" name="bookId" readonly>
                                </td>
                           </tr> 
                            <tr>
                                <td>
                                    <label>
                                        Issue To : 
                                    </label>
                                </td>
                                <td>
                                    <input class="rounded" type="text" name="studentId" placeholder="Enter the student's ID" required>
                                </td>
                            </tr>
                        </table>
                        <input id="studentId" class="submitRounded" type="submit" value="Submit" name="submit">
                    </form>
                </center>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('librarianHome.librarianMenuConnector', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/librarianHome/librarianIssueToStud.blade.php ENDPATH**/ ?>