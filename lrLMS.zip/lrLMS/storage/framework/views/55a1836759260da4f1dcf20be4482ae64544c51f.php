<?php $__env->startSection('searchResults'); ?>
<div class="transs">
	<div class="blurs">
		<h4 align="center" style="margin-bottom: 1%;margin-top: 2%">Searched by Books</h4>
		<table style="width:99%;margin-left:0.5%;padding-bottom:0.5%;font-size:25px;">
			<tr style="font-size:30px;">
				<th><center>BID</center></th>
				<th><center>Book Name</center></th>
				<th><center>Author Name</center></th>
				<th><center>Published By</center></th>
				<th><center>Available</center></th>
			</tr>
			<?php for($x=1; $x <= 10; $x++): ?>
				<tr>
					<td>
						<center><?php echo $x; ?></center>
					</td>
					<td><center>R.D. Sharma</center></td>
					<td><center>R.D. Sharma</center></td>
					<td><center>R.D. Sharma</center></td>
					<td><center>Yes / No</center></td>
				</tr>
			<?php endfor; ?>
		</table>

	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('studentHome.studentSearch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/studentHome/studentSearchBooks.blade.php ENDPATH**/ ?>