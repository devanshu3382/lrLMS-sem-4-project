<?php $__env->startSection('css'); ?>
.rounded
{
    font-size:16pt;
    border-radius:20px;
    min-width:150px;
    box-shadow: 2px 2px 3px #666;
    padding-left: 10px;
}
.submitRounded{
    background-color:#4CAF50;
    margin-left:20px;
    margin-top:15px;
    margin-bottom:15px;
    font-size:16pt;
    width:150px;
    color:white;
    border-radius:25px;
    box-shadow: 2px 2px 3px #666;
}
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Student Corner | Settings | Make Changes</title>


<?php $__env->startSection('content'); ?>
<div class="trans1">
    <center>
        <h1>
            Edit Contact Details
        </h1>
    </center>
    <form method="post">
    <?php echo csrf_field(); ?>
        <center>
            <table style="font-size:2rem;" cellspacing="10px" cellpadding="10px">
                <tr>
                    <td>
                        Contact Number :
                    </td>
                    <td>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="text" class="rounded" name="phNum" value="<?php echo e($data->contact_details); ?>" placeholder="+910123456789">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        E-Mail Address :
                    </td>
                    <td>
                    <input type="hidden" name="studentId" value="<?php echo e($data->idstudents); ?>">
                        <input type="text" class="rounded" name="email" value="<?php echo e($data->email); ?>" placeholder="abc@gmail.com">
                    </td>
                </tr>
            </table>
            <input formaction="<?php echo e(url('/student/settings')); ?>" class="rounded" type="submit" value="Back">
            <input formaction="<?php echo e(url('/student/update-details')); ?>" class="submitRounded" type="submit" value="Submit" name="submit">
        </center>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('studentHome.studentSetting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/studentHome/studentSettingChangeContactDetails.blade.php ENDPATH**/ ?>