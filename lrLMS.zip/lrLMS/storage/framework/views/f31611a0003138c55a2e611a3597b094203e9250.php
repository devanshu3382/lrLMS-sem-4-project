<?php $__env->startSection('view'); ?>
<center>
    <table style="width:98%;margin-left:0%;padding-bottom:0.5%;font-size:25px;">
        <tr>
            <th><center>BID</center></th>
            <th style="padding-left:2rem">Book Name</th>
            <th style="padding-left:0.5rem">Author Name</th>
            <th style="padding-right:0rem">Published By</th>
            <th><center>Operations</center></th>
        </tr>
    </table>
</center>
<center style="position: fixed; height: 600px; width: 76%; overflow: scroll; overflow-x:hidden">
    <table style="width:98%;margin-left:0%;padding-bottom:0.5%;font-size:25px;">
        <?php 
            $x=1;
            for ($x=1; $x <= 20; $x++) { 	
        ?>	
                <tr class="hover">
                <td style="padding-left: 1rem">
                    <center><?php echo $x; ?></center>
                </td>
                <td style="padding-left: 0.5rem"><center>R.D. Sharma</center></td>
                <td ><center>R.D. Sharma</center></td>
                <td><center>R.D. Sharma</center></td>
                <td ><center><button id="<?php echo $x ?>" class="button-edit" onclick="editBooks(id)">Edit</button></center></td>
                <td ><center><button id="<?php echo $x ?>" class="button-remove" onclick="removeBooks(id)">Remove</button></center></td>
        </tr>
        <?php
            }
        ?>
    </table>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('librarianHome.librarianManageBooksLanding', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/librarianHome/LibrarianManageBooks.blade.php ENDPATH**/ ?>