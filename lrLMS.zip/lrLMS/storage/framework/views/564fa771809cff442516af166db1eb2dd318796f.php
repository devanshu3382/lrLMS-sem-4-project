<?php $__env->startSection('css'); ?>
.rounded
{
    font-size:16pt;
    border-radius:20px;
    min-width:150px;
    box-shadow: 2px 2px 3px #666;
    padding-left: 10px;
}
.submitRounded{
    background-color:#4CAF50;
    margin-left:20px;
    margin-top:15px;
    margin-bottom:15px;
    font-size:16pt;
    width:150px;
    color:white;
    border-radius:25px;
    box-shadow: 2px 2px 3px #666;
}
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Student Corner | Settings | Change Password</title>


<?php $__env->startSection('content'); ?>
<div class="trans1">
    <center>
        <h1>
            Change Password
        </h1>
    </center>
    <form method="post">
    <?php echo csrf_field(); ?>
        <center>
            <table style="font-size:2rem;" cellspacing="10px" cellpadding="10px">
                <tr>
                    <td>
                        Current Password :
                    </td>
                    <td>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="text" class="rounded" name="studentId" value="<?php echo e($data->idstudents); ?>" hidden>
                        <input type="text" class="rounded" name="name" value="<?php echo e($data->name); ?>" hidden>
                        <input type="text" class="rounded" name="enrollNo" value="<?php echo e($data->enrollment_number); ?>" hidden>
                        <input type="text" class="rounded" name="course" value="<?php echo e($data->course); ?>" hidden>
                        <input type="text" class="rounded" name="div" value="<?php echo e($data->division); ?>" hidden>
                        <input type="text" class="rounded" name="sem" value="<?php echo e($data->semester); ?>" hidden>
                        <input type="text" class="rounded" name="contact" value="<?php echo e($data->contact_details); ?>" hidden>
                        <input type="text" class="rounded" name="email" value="<?php echo e($data->email); ?>" hidden>
                        <input type="text" class="rounded" name="oldPasswd" value="<?php echo e($data->password); ?>" hidden>
                        <input type="password" class="rounded" name="password" placeholder="Enter current password">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td style="font-size: 20px">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        New Password :
                    </td>
                    <td>
                        <input type="password" class="rounded" name="newPassword" value="" placeholder="Enter New Password">
                    </td>
                    <td style="font-size: 20px">
                    <?php $__errorArgs = ['newPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </table>
            <input formaction="<?php echo e(url('/student/settings')); ?>" class="rounded" type="submit" value="Back">
            <input formaction="/student/update/password" class="submitRounded" type="submit" value="Submit" name="submit">
        </center>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('studentHome.studentSetting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/studentHome/studentSettingChangePassword.blade.php ENDPATH**/ ?>