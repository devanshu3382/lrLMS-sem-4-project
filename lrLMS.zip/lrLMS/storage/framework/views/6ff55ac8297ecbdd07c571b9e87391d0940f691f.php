<?php echo e($details['subject']); ?>

<br>
<h1>
    <?php echo e($details['message']); ?>

</h1>
<br>
<?php echo e('Thank You'); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/mails/testmail.blade.php ENDPATH**/ ?>