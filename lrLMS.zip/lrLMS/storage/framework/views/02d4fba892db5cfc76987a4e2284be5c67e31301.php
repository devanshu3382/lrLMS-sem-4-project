<?php $__env->startSection('css'); ?>
.trans3{
	background-color:white;
	opacity:0.7;
	border-radius:20px;
}
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<title>Student Corner | Total Books Issued</title>

<?php $__env->startSection('content'); ?>
<div class="trans3">
	<div class="blur1">
		<center>
			<h1 style="font-size: 1.2em;color:black">
				Books issued to you currently
			</h1>
			<table border="0" style="width:100%;font-size:25px;" cellspacing="2px" cellpadding="2px">
				<tr style="font-size:30px;background:black;color:white;">
					<th>Issue<br>ID</th>
					<th>Book<br>Name</th>
					<th>Author<br>Name</th>
					<th>Issue<br>Date</th>
                    <th>Due<br>Date</th>
                    <th>Fined</th>
				</tr>
                <tr style="margin-top:50px;">
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td></td>
                </tr>
                <tr style="margin-top:50px;">
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                </tr>
                
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td>
							<center><?php echo $x->issue_id; ?></center>
						</td>
						<td><center><?php echo e($x->book_name); ?></center></td>
						<td><center><?php echo e($x->book_author); ?></center></td>
						<td><center><?php echo e($x->issue_date); ?></center></td>
						<td><center><?php echo e($x->due_date); ?></center></td>
						<?php if($x->fined==0): ?>
						<td><center>No</center></td>
						<?php else: ?>
						<td><center><?php echo e($x->fined); ?></center></td>
						<?php endif; ?>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</center>	
	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('studentHome.studentLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/studentHome/studentCurrentBooksIssued.blade.php ENDPATH**/ ?>