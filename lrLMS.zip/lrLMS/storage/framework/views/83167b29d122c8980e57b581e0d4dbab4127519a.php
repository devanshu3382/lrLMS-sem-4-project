

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('home.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog\resources\views/home/loginAsStudent.blade.php ENDPATH**/ ?>