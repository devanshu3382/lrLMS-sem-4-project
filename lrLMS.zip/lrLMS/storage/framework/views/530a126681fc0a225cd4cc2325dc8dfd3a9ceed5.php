<table cellspacing="10rem">
    <tr>
        <th>
            student-id
        </th>
        <th>
            name
        </th>
        <th>
            enrollment-number
        </th>
        <th>
            email
        </th>
        <th>
            contact-details
        </th>
        <th>
            password
        </th>
        <th>
            course
        </th>
        <th>
            semester
        </th>
        <th>
            division
        </th>
        <th align="center" colspan="2">
            Action
        </th>
    </tr>
    
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <?php echo e($i -> idstudents); ?>

        </td>
        <td>
            <?php echo e($i -> course); ?>

        </td>
        <td>
            <?php echo e($i -> semester); ?>

        </td>
        <td>
            <?php echo e($i -> division); ?>

        </td>
        <td>
            <?php echo e($i -> enrollment_number); ?>

        </td>
        <td>
            <?php echo e($i -> email); ?>

        </td>
        <td>
            <?php echo e($i -> password); ?>

        </td>
        <td>
            <?php echo e($i -> contact_details); ?>

        </td>
        <td>
            <?php echo e($i -> name); ?>

        </td>
        <td>
            <a href="/editstudent/<?php echo e($i -> idstudents); ?>"> Edit </a>
        </td>
        <td>
            <a href="/deletestudent/<?php echo e($i -> idstudents); ?>"> Delete </a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php if($message=Session::get('success')): ?>
    <script>
        alert('<?php echo e($message); ?>')
    </script>
<?php endif; ?> <?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/show-student.blade.php ENDPATH**/ ?>