
<?php $__env->startSection('css'); ?>



<?php $__env->startSection('content'); ?>
<center>
<div class="transparent">
    <h1>
        <center>
            Library Management System
        </center>
    </h1>
    <marquee direction="left">
        <b>
            Login OR Sign Up as a Student or Librarian to gain access any of the features provided by Library Management System.
        </b>
    </marquee>
</div>
</center>
<center>
    <div class="transMenu container">
    
        <a class="absolute1" href="<?php echo e(route('home.loginA')); ?>" style="font-size:30px;font-weight:bold;">Login As Admin</a>
    
        <a class="absolute2" href="<?php echo e(route('home.loginL')); ?>" style="font-size:30px;font-weight:bold;">Login As Librarian</a>
   
        <a class="absolute3" href="<?php echo e(route('home.loginS')); ?>" style="font-size:30px;font-weight:bold;">Login As Student</a>
    </div>
</center>
<?php echo $__env->make('home.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog\resources\views/home/loginALS.blade.php ENDPATH**/ ?>