<?php $__env->startSection('searchResults'); ?>
<div class="transs">
	<div class="blurs">
		<h4 align="center" style="margin-bottom: 1%;margin-top: 2%">Results</h4>
		<table style="width:99%;margin-left:0.5%;padding-bottom:0.5%;font-size:25px;">
			<tr style="font-size:30px;">
				<th><center>BID</center></th>
				<th><center>Book Name</center></th>
				<th><center>Author Name</center></th>
				<th><center>Published By</center></th>
				<th><center>Number <br> Of Books</center></th>
				<th><center>Action</center></th>
			</tr>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td>
					<center><?php echo $x->id_books; ?></center>
				</td>
				<td><center id="id"><?php echo $x->name ?></center></td>
				<td><center id="id"><?php echo $x->author ?></center></td>
				<td><center id="id"><?php echo $x->publisher ?></center></td>
				<td><center id="id"><?php echo $x->number_of_books ?></center></td>
				<td><center>
					<?php if($x->number_of_books!=0): ?>
					<button class="reserve-btn" id="<?php echo $x->id_books; ?>" onclick = "confirmReservation(this)"> 
						Reserve
					</button>
					<?php endif; ?>
					<?php if($x->number_of_books==0): ?>
					<button id="<?php echo $x->id_books; ?>"> 
						Reserve
					</button>
					<?php endif; ?>
					</center>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
		</table>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('studentHome.studentReserveBook', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/studentHome/studentReservePublishers.blade.php ENDPATH**/ ?>