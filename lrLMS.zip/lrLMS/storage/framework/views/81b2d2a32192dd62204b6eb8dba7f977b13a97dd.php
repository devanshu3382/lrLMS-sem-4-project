<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="trans1">
	<div class="trans2">
		<center>
			<h1 style="color:black">
				Browse table comes here
			</h1>
			<table border="2" style="width:100%;">
				<tr>
					<th>BID</th>
					<th>Book Name</th>
					<th>Author Name</th>
					<th>Published By</th>
					<th>Available</th>
				</tr>
				<?php 
					$x=1;
					for ($x=1; $x <= 50; $x++) { 	
				?>	
						<tr>
						<td>
							<?php echo $x; ?>
						</td>
						<td>RD Sharma</td>
						<td>RD Sharma</td>
						<td>RD Sharma</td>
						<td>Yes</td>
					</tr>
				<?php
					}
				?>
					
			</table>
		</center>	
	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('studentHome.studentLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Desktop/blog/resources/views/studentHome/studentBrowse.blade.php ENDPATH**/ ?>