<?php $__env->startSection('css'); ?>
.trans3{
	background-color:white;
	opacity:0.7;
	border-radius:20px;
}
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<title>Student Corner | Total Books Issued</title>

<?php $__env->startSection('content'); ?>
<div class="trans3">
	<div class="blur1">
		<center>
			<h1 style="font-size: 1.2em;color:black">
				Books reserved by you
			</h1>
			<table border="0" style="width:100%;font-size:25px;" cellspacing="5px" cellpadding="2px">
				<tr style="font-size:30px;background:black;color:white;">
					<th>Reservation<br>Id</th>
					<th>Book Id</th>
					<th>Book Name</th>
					<th>Author Name</th>
					<th>Reserved On</th>
                    <th>Operation</th>
				</tr>
                <tr style="margin-top:50px;">
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                </tr>
                <tr style="margin-top:50px;">
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                    <td> </td>
                </tr>
            
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($x->cancelled==0 and $x->time<=10800): ?>
						<tr>
							<td>
								<center><?php echo $x->reservation_id; ?></center>
							</td>
							<td><center><?php echo e($x->book_id); ?></center></td>
							<td><center><?php echo e($x->book_name); ?></center></td>
							<td><center><?php echo e($x->book_author); ?></center></td>
							<td><center><?php echo e($x->reservation_time); ?></center></td>
							<td><center><a href="/student/cancel-reservation/<?php echo e($x->reservation_id); ?>" style="border-radius:5px;color:red;padding:6px">Cancel</a></center></td>
						</tr>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</center>	
	</div>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('studentHome.studentLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/studentHome/studentCurrentReservation.blade.php ENDPATH**/ ?>