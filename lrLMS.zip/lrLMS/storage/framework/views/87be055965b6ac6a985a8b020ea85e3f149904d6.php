
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<center>
<div class="transparent">
    <h1>
        <center>
            Library Management System
        </center>
    </h1>
    <center>
        <b style="font-size:35px">
            LOGGING IN AS ADMIN
        </b>
    </center>
</div>
</center>
<center>
    <div class="transMenu container">
        <table cellspacing="30px">
            <legend style="font-size:35px;font-weight:900">LogIn</legend>
            <form action="#" method="POST">
                <tr>
                    <td>
                        <b style="font-size:25px;">
                            E-Mail :
                        </b>
                    </td>
                    <td>
                        <input type="text" name="email" placeholder="abc@gmail.com" 
                            class="rounded"/>
                    </td>
                </tr>
                <tr>
                    <td>
                    <b style="font-size:25px;">
                            Password :
                        </b>
                    </td>
                    <td>
                    <input type="text" name="password" placeholder="**********" 
                            class="rounded"/>
                    </td>
                </tr>

        </table>
    </div>
               <input type="button" name="submit" value="Submit" style="background-color:#4CAF50;margin-top:15px;font-size:16pt;width:150px;border-radius:25px;box-shadow: 2px 2px 3px #666;height:35px;"/>
            </form>    
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog\resources\views/home/loginA.blade.php ENDPATH**/ ?>