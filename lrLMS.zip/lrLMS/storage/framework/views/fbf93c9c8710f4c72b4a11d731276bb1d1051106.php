<!DOCTYPE html>
<html>
	<head>
		<title>Library Management System</title>
		<style type="text/css">
			div *.overflow:auto;
			h{}
			
			body{
				background-image:url('https://cdn11.bigcommerce.com/s-ka7ofex/images/stencil/2000x1000/uploaded_images/how-rfid-is-making-libraries-smarter.jpg?t=1580145106');
			}
			h1{
				margin: 5%;					/*to show data in transparent box*/ 
				font-weight: bold;			/*concept(we must increase the z layer)*/ 
				color: black;				/*Color of the fonts*/
				
				margin-top:1%;
				margin-bottom:5px;
				border-style:solid;
				border-top:0;
				border-left:0;
				border-right:0;
				font-size:3.5em;
			}
			.transparent{
				margin: 0;
				background-color: #ffffff;
				border: 1px solid black;
				width:100;
				/* border-radius:20px; */
				opacity: 0.7;
			}
			.transparent form{
				margin: 10em;
				background-color: #ffffff;
				border: 1px solid black;
				width:100;
				/* border-radius:20px; */
				opacity: 0.7;				
			}
			marquee{
				font-size:25px;
			}
		</style>
	</head>
	<body>
		<div class="transparent">
			<h1>
				<center>
					Library Management System
				</center>
			</h1>
			<marquee direction="left">
				<b>
					Login OR Sign Up as a Student or Librarian to gain access any of the features provided by Library Management System.
				</b>
			</marquee>
		</div>

		<div class="transparent">
			<a href="<?php echo e(Route); ?>"></a>
		</div>
	</body>
</html><?php /**PATH C:\wamp64\www\blog\resources\views/home.blade.php ENDPATH**/ ?>