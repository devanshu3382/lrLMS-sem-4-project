<?php $__env->startSection('searchResults'); ?>
<div class="blurs">
	<div class="transs">
		<h4 align="center" style="margin-bottom: 1%;margin-top: 2%">Searched by Book ID</h4>
		<table style="width:99%;margin-left:0.5%;padding-bottom:0.5%;font-size:25px;">
			<tr style="font-size:30px;background:white;">
				<th><center>BID</center></th>
				<th><center>Book Name</center></th>
				<th><center>Author Name</center></th>
				<th><center>Published By</center></th>
				<th style="background:white;"><center>Issue</center></th>
			</tr>
			
			<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($x->number_of_books!=0): ?>	
					<tr>
						<td>
							<center><?php echo $x->id_books; ?></center>
						</td>
						<td><center><?php echo $x->name ?></center></td>
						<td><center><?php echo $x->author ?></center></td>
						<td><center><?php echo $x->publisher ?></center></td>
						<td style="background:white;"><center><button id="<?php echo $x->id_books ?>" onclick="selectBook(this)">Issue</button></center></td>
					</tr>
					<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('librarianHome.librarianIssueLanding', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/librarianHome/librarianIssueSearchResultsBookAuthor.blade.php ENDPATH**/ ?>