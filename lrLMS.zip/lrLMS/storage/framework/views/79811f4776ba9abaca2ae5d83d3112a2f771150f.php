
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<center>
<div class="transparent">
    <h1>
        <center>
            Library Management System
        </center>
    </h1>
    <center>
        <b style="font-size:25px">
            <marquee direction="left">
                Log In as a student first to use our services. If you do not have an account
                <a href="<?php echo e(url('/homeSignup')); ?>" style="font-weight:900;text-decoration:none"><b>create one here</b></a>.
            </marquee>
        </b>
    </center>
</div>
</center>
<center>
    <div class="transMenu container">
        <table cellspacing="30px">
            <legend style="font-size:35px;font-weight:900">Log In</legend>
            <form action="/student-login" method="POST">
            <?php echo csrf_field(); ?>
                <tr>
                    <td>
                        <b style="font-size:25px;">
                            E-Mail :
                        </b>
                    </td>
                    <td>
                        <input type="text" name="email" autofocus placeholder="abc@gmail.com" 
                            class="rounded" required/>
                    </td>
                </tr>
                <tr>
                    <td>
                    <b style="font-size:25px;">
                            Password :
                        </b>
                    </td>
                    <td>
                    <input type="password" name="password" placeholder="**********" 
                            class="rounded" required/>
                    </td>
                </tr>

        </table>
    </div>
    <div class="container2">
        <p style="font-weight:900;">
            <a href="<?php echo e(url('/homeSignup')); ?>">
                New User? Sign Up Here
            </a>
        </p>
                <input type="submit" name="submit" value="Submit" style="background-color:#4CAF50;margin-top:15px;font-size:16pt;width:150px;border-radius:25px;box-shadow: 2px 2px 3px #666;height:35px;"/>
            </form>   
    </div>            
    <?php if($message=Session::get('success')): ?>
    <script>
        alert('<?php echo e($message); ?>')
    </script>
    <?php endif; ?>    
    <?php if($message=Session::get('failure')): ?>
    <script>
        alert('<?php echo e($message); ?>')
    </script>
    <?php endif; ?>    
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/devanshuparmar/Documents/Sem 4 Practicals+Project/lrLMS/resources/views/home/studentLogin.blade.php ENDPATH**/ ?>