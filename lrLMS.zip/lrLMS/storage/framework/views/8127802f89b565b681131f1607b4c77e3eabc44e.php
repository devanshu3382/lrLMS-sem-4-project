
<?php $__env->startSection('css'); ?>

<?php $__env->startSection('content'); ?>

<center>
    <div class="transparent">
        <h1>
            <center>
                Library Management System
            </center>
        </h1>
        <center>
            <b style="font-size:25px">
                <marquee direction="left">
                    Log In or Sign Up as a student first to use our services.
                    <a href="<?php echo e(url('/home')); ?>" style="font-weight:900;text-decoration:none"><b> Log In here.</b></a> If you do not have an account  
                    <a href="<?php echo e(url('/homeSignup')); ?>" style="font-weight:900;text-decoration:none"><b>create one here</b></a>.
                </marquee>
            </b>
        </center>
    </div>
</center>
<center>
    <div class="transSignup container3">
        <table cellspacing="30px">
            <legend style="font-size:35px;font-weight:900">Sign Up</legend>
            <form action="#" method="POST">
                <tr>
                    <td>
                        <b style="font-size:25px;">
                            Name :
                        </b>
                    </td>
                    <td>
                        <input type="text" name="name" autofocus placeholder="firstname lastname" 
                            class="rounded"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b style="font-size:25px;">
                                Enrolment Number :
                            </b>
                    </td>
                    <td>
                        <input type="textfield" name="enrollNo" placeholder="12 digit enrolment number" 
                                class="rounded"/>
                        </td>
                </tr>
                <tr>
                    <td>
                        <b style="font-size:25px;">
                            Course :
                        </b>
                    </td>
                    <td>
                        <select name="course" style="font-size:16pt;width:100pt;border-radius:20px;box-shadow: 2px 2px 3px #666">
                            <option value="IMCA">IMCA</option>
                            <option value="MCA">MCA</option>
                            <option value="BCA">BCA</option>
                            <option value="BBA">BBA</option>
                            <option value="MBA">MBA</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b style="font-size:25px;">
                            Semester :
                        </b>
                    </td>
                    <td>
                        <select name="sem" style="font-size:16pt;width:100pt;border-radius:20px;box-shadow: 2px 2px 3px #666">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b style="font-size:25px;">
                            Division :
                        </b>
                    </td>
                    <td>
                        <select name="sem" style="font-size:16pt;width:100pt;border-radius:20px;box-shadow: 2px 2px 3px #666">
                            <option value="ICA">ICA</option>
                            <option value="IET">IET</option>
                            <option value="IMS">IMS</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b style="font-size:25px;">
                                Contact :
                            </b>
                    </td>
                    <td>
                        <input type="textfield" name="contact" placeholder="+910123456789" 
                                class="rounded"/>
                        </td>
                </tr>
                <tr>
                    <td>
                        <b style="font-size:25px;">
                                E-Mail :
                            </b>
                    </td>
                    <td>
                        <input type="email" name="email" placeholder="abc@gmail.com" 
                                class="rounded"/>
                        </td>
                </tr>
                <tr>
                    <td>
                        <b style="font-size:25px;">
                                Password :
                            </b>
                    </td>
                    <td>
                        <input type="password" name="password" 
                                class="rounded"/>
                        </td>
                </tr>

        </table>
    </div>
    <div class="container2">
        <p style="font-weight:900;">
            <a href="<?php echo e(url('/home')); ?>">
                Already a user? Login Here
            </a>
        </p>
                    <input type="button" name="submit" value="Submit" style="background-color:#4CAF50;margin-top:15px;margin-bottom:10%;font-size:16pt;width:150px;border-radius:25px;box-shadow: 2px 2px 3px #666;height:35px;"/>
            </form>   
    </div>
</center>
<?php echo $__env->make('home.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\blog\resources\views/home/studentSignup.blade.php ENDPATH**/ ?>