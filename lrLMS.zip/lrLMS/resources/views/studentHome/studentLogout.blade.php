session_destroy();
<script>
    window.location="{{url('/logout')}}";
</script>