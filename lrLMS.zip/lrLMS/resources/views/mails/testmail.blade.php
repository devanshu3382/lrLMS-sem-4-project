{{$details['subject']}}
<br>
<h1>
    {{$details['message']}}
</h1>
<br>
{{'Thank You'}}